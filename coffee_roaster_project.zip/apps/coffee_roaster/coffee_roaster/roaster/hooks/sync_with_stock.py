# Simulated ERPNext Stock Linkage

def sync_stock_entry():
    print('Syncing Roast Batch with Stock Entry...')