# Simulated Roast Machine Import Hook

def import_roast_logs():
    print('Importing roast logs from connected machine...')