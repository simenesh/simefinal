// customer_feedback.js
frappe.ui.form.on('Customer Feedback', {
  refresh: function(frm) {
    // Custom logic
  }
});
