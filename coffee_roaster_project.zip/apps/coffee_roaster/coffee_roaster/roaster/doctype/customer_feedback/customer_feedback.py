# customer_feedback.py
import frappe
from frappe.model.document import Document

class CustomerFeedback(Document):
    pass
