# Copyright (c) 2025, Coffee Roaster and contributors
# For license information, please see license.txt

from frappe.model.document import Document

class Opportunity(Document):
    pass
