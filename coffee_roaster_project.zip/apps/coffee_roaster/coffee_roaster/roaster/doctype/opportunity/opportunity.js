frappe.ui.form.on('Opportunity', {
    refresh: function(frm) {
        // Custom actions or buttons can go here
    }
});
