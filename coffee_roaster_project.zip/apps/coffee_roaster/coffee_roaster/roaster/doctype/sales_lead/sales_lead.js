frappe.ui.form.on('Sales Lead', {
    refresh: function(frm) {}
});
