from frappe.model.document import Document

class SalesLead(Document):
    pass
