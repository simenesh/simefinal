frappe.ui.form.on('Customer', {
    refresh: function(frm) {
        // Add custom behavior here
    }
});
