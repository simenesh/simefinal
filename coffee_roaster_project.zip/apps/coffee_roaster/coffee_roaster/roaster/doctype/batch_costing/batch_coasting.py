# coffee_roaster/batch_costing/batch_costing.py
import frappe
from frappe.utils import flt, today

def make_batch_cost(doc, method):
    """Create or update Batch Cost when Roast Batch is submitted."""
    if doc.docstatus != 1:            # only after submit
        return

    # 🔹 0) ensure we have ONE target doc (update if it already exists)
    bc = frappe.get_doc("Batch Cost", {"batch_no": doc.name}) \
         if frappe.db.exists("Batch Cost", {"batch_no": doc.name}) \
         else frappe.new_doc("Batch Cost")
    bc.batch_no       = doc.name
    bc.output_weight  = doc.output_weight or 0
    bc.raw_bean_costs = []
    bc.overheads      = []
    bc.packaging_costs = []

    # 1️⃣ RAW BEANS -----------------------------------------------------------
    raw_items = frappe.db.get_all(
        "Stock Entry Detail",
        filters={"parent": doc.stock_entry, "is_finished_item": 0},
        fields=["item_code", "transfer_qty AS qty", "basic_rate"]
    )
    for it in raw_items:
        bc.append("raw_bean_costs", {
            "item_code": it.item_code,
            "qty_kg":    flt(it.qty),
            "rate":      flt(it.basic_rate),
            "amount":    flt(it.qty) * flt(it.basic_rate)
        })

    # 2️⃣ OVERHEADS (template) -----------------------------------------------
    template = frappe.db.get_single_value("Roaster Settings", "overhead_template")
    if template:
        tmpl = frappe.get_doc("Roasting Overhead Template", template)
        for row in tmpl.items:
            bc.append("overheads", {          # qty/rate copied 1-to-1
                "overhead_type": row.overhead_type,
                "basis":         row.basis,
                "qty":           row.qty,
                "rate":          row.rate,
                "amount":        0  # placeholder for now
            })

    # 3️⃣ PACKAGING -----------------------------------------------------------
    for p in doc.get("packaging_used", []):
        bc.append("packaging_costs", {
            "packaging_item": p.item_code,
            "uom":            p.uom,
            "qty":            p.qty,
            "rate":           p.rate,
            "amount":         flt(p.qty) * flt(p.rate)
        })

    # 4️⃣ TOTALS & %-overhead -------------------------------------------------
    bc.total_raw_beans_cost    = sum(r.amount for r in bc.raw_bean_costs)
    for o in bc.overheads:
        if o.basis == "Flat":
            o.amount = flt(o.rate)
        elif o.basis == "Per kg":
            o.amount = flt(o.rate) * flt(bc.output_weight)
        elif o.basis == "Percent":
            o.amount = (flt(o.rate) / 100) * bc.total_raw_beans_cost

    bc.total_roasting_overhead = sum(o.amount for o in bc.overheads)
    bc.total_packaging_cost    = sum(p.amount for p in bc.packaging_costs)
    bc.total_batch_cost        = flt(
        bc.total_raw_beans_cost +
        bc.total_roasting_overhead +
        bc.total_packaging_cost
    )
    bc.cost_per_kg = flt(bc.total_batch_cost / bc.output_weight, 2) \
                     if bc.output_weight else 0

    bc.flags.ignore_permissions = True
    bc.save()
    if bc.docstatus == 0:
        bc.submit()

    create_wip_journal_entry(bc)

# ---------------------------------------------------------------------------

def create_wip_journal_entry(bc):
    """Posts a Journal Entry moving cost into WIP."""
    if frappe.db.exists("Journal Entry", {"remark": ["=", f"Batch costing for {bc.batch_no}"]}):
        return  # already posted

    company     = frappe.defaults.get_global_default("company")
    cost_center = frappe.defaults.get_global_default("cost_center")
    wip_account = frappe.db.get_value("Company", company, "default_inventory_account")

    je = frappe.new_doc("Journal Entry")
    je.voucher_type = "Journal Entry"
    je.posting_date = today()
    je.remark       = f"Batch costing for {bc.batch_no}"

    je.append("accounts", {
        "account":  wip_account,
        "debit_in_account_currency": bc.total_batch_cost,
        "cost_center": cost_center
    })
    for head, amount in (
        ("Raw Materials Cost",      bc.total_raw_beans_cost),
        ("Roasting Overhead",       bc.total_roasting_overhead),
        ("Packaging Materials Cost",bc.total_packaging_cost),
    ):
        if amount:
            je.append("accounts", {
                "account": head,
                "credit_in_account_currency": amount,
                "cost_center": cost_center
            })
    je.flags.ignore_permissions = True
    je.submit()
