# Copyright (c) ...
# License: MIT. See LICENSE
# 

from frappe.model.document import Document

class RoasterSettings(Document):
    pass
