frappe.ui.form.on('Communication Log', {
  refresh(frm) {
    frm.set_intro("Track all interactions with leads or customers.");
  }
});
