from frappe.model.document import Document

class CustomerInteraction(Document):
    pass
