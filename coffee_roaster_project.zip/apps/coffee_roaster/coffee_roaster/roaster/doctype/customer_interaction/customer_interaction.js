frappe.ui.form.on('Customer Interaction', {
    refresh: function(frm) {}
});
