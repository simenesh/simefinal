// Copyright (c) 2025, sime and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Roasting Machine", {
// 	refresh(frm) {

// 	},
// });
