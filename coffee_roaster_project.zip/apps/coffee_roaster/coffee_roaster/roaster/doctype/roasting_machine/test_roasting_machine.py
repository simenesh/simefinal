# Copyright (c) 2025, sime and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestRoastingMachine(FrappeTestCase):
	pass
